PROJECT 8 README
Created by: Austin Johns

1. To run this program, open the main.cpp file in your favorite C++ compiler.
	NOTE: To run the program, both libraries for GLUT and OpenGL must be installed locally on your computer.

2. Once running, click inside the window to change which axis the cube is rotating on.