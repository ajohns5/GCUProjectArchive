Project 9: Advanced Shaders

To compile this project, load every file in the zip into a project in your C++ IDE of choice.

Run the program.