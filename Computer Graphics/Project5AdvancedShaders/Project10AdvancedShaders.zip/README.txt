Project 10: Advanced Shaders 2 README
/////////////////////////////////////
To run this project, add all files included in this .zip file to a C++ compiling IDE of your choice. Run the program and use the controls to move the camera to explore textures.