README


To install and use the Lexer, follow the steps.
	1. Install the file, "lexer.py" into your IDE of choice. 
	2. Intall the file, "lexer.GCU-PL" into the same folder in your directory to
	be read by the program.
	3. Run the program. 
