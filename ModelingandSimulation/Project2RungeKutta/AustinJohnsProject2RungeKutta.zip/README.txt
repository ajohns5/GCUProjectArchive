README Runge-Kutta Project

To use this program, please open "AustinJohnsProject2RungeKutta.py" in a program that can compile a program written in Python. 

If you would like to alter the x0, y0, or h values, the values can be changed in lines 34-36 of the project.