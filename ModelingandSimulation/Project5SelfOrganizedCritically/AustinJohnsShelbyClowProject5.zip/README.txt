README

Austin Johns and Shelby Clow

To open this program, open the file, “LorenzODE.py,” in a python compiler and run the program. 

