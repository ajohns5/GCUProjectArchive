README for Project 6 using Taylor Series


Included files:
	README.txt
	Project6TaylorSeries.py

To run the program:
	-Open "Project6TaylorSeries.py" in an IDE that can handle Python code.
		*We used Juypter and PyCharm
	-Using the given code, install packages numpy, sympy, odeint.
	-Run the program