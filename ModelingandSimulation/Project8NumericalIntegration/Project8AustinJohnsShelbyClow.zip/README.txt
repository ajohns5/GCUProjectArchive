Project 8: Numerical Integration README

Files included in this project:
	1. Project8part1a.py
	2. Project8part1b.py
	3. Project8part1c.py
	4. Project8part2.py
	5. README.txt

To execute the project: 
	- Import files 1-4 into a IDE that can handle Python code.
		-In this class, I am using PyCharm and Juypter Notebook.
	- Import any necessary libraries as introduced at the beginning of each python 
	file.
	- Run each python file in the IDE.



NOTE TO THE PROFESSOR

Professor Citro, thank you for a great summer semester. Although it is tough with being fully online, your class was a joy and we both enjoyed it. Thank you!